// assignment No 1 // 

// Question No 1 start //

// let num1 = parseInt(prompt('please enter first number'));
// let num2 = parseInt(prompt('please enter second number'));

// if ( num1 > num2){
// 	console.log(num1 +" is greater than "+ num2)
// }
// else if (num2 > num1){
// 	console.log(num2 +" is greater than " + num1)
// }
// else{
// 	console.log ("Both " + num1 + " and  " +num2 +" are equal" )
// }

// Question No 1 Ends //

// Question No 2 starts //

// let conditionalNum1 = parseInt (prompt('check number it is poitive or negative'))

// if (conditionalNum1 < 0 ) {
// 	alert('the sign is -')
// }
// else if ( conditionalNum1 > 0) {
// 	alert('the sign is +')

// }
// else{
// 	alert('the number is Zero')

// }

// Question No 2 ends //

// Question No 3 starts //

// let num1 = parseInt(prompt("Enter number 1:"));
// let num2 = parseInt(prompt("Enter number 2:"));
// let num3 = parseInt(prompt("Enter number 3:"));
// let num4 = parseInt(prompt("Enter number 4:"));
// let num5 = parseInt(prompt("Enter number 5:"));



// if (num1 >= num2 && num1 >= num3 && num1 >= num4 && num1 >= num5) {
//   console.log(num1 +" is largest")
// } else if (num2 >= num1 && num2 >= num3 && num2 >= num4 && num2 >= num5) {
//   console.log(num2 +" is largest")
// } else if (num3 >= num1 && num3 >= num2 && num3 >= num4 && num3 >= num5) {
//   console.log(num3 +" is largest")
// } else if (num4 >= num1 && num4 >= num2 && num4 >= num3 && num4 >= num5) {
//   console.log(num4 +" is largest")
// } else {
//   console.log(num5 +" is largest")
// }
// Question No 3 Ends //

// Question No 4 Starts //


// for (let i = 0; i <= 15; i++) {
	
// 	if (i % 2 ===0) {
// 		document.write (i + " is even")
// 	}
// 	else {
// 		document.write(i + " is odd")
// 	}
// }

// Question No 4 Ends //

// Question No 5 Starts//

// let abcd = prompt("Please enter your marks");;

// if (abcd >= 90 && abcd <=100){
//    console.log ('A')
// }
// else if ( abcd >=80 && abcd <90){
//     console.log ('B')
// }
// else if ( abcd >=70 && abcd <80){
//     console.log ('C')
// }
// else if ( abcd >=60 && abcd <70){
//     console.log ('D')
// }
// else if (abcd <60){
//     console.log ('F')
// }

// else {
//     console.log('Please enter a valid number between 0 and 100')
// }

// Question No 5 Ends //


// Question No 6 Starts //

// for (let i = 1; i <= 100; i++) {
//   if (i % 3 === 0 && i % 5 === 0) {
//     document.write("Fizz Buzz");
//     document.write("<br>");

//   } else if (i % 3 === 0) {
//     document.write("Fizz");
//     document.write("<br>");

//   } else if (i % 5 === 0) {
//     document.write("Buzz");
//     document.write("<br>");

//   } else {
//     document.write(i);
//     document.write("<br>");

//   }
// }

// Question No 6 Ends //

// Question No 7 starts //

// for (let i = 1; i <=5; i++) {
// 	let row = ""
// 	for (let j = 1; j<= i; j++) {
// 		row +="*" 
// 	}
// document.write(row)
// }

// Question No 7 Ends //
